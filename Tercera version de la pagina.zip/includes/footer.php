<footer class="footerSuperior">
  <nav class="footernav1">
    <div class="footer-container1" style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 20px;">
      <div>
        <strong>Síguenos:</strong>
        <a href="https://www.instagram.com/hornosnachitos/?hl=es" target="_blank" style="display: inline-block;">
          <img src="/nachitos/imagenes/instagram.png" alt="Instagram" style="width:32px; height:32px; vertical-align: middle;">
        </a>
        <a href="https://www.facebook.com/nachitoschile/" target="_blank" style="display: inline-block;">
          <img src="/nachitos/imagenes/facebook.png" alt="Facebook" style="width:32px; height:32px; vertical-align: middle;">
        </a>
      </div>
      <div>
        <strong>Contacto:</strong>
        <p style="margin: 0;">Email: contacto@nachitos.com</p>
        <p style="margin: 0;">Tel: +56 9 7488 8341</p>
        <p style="margin: 0;">Ubicación:</p>
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3088.731250577523!2d-72.25514548788225!3d-39.271663971528355!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9614619e2b062279%3A0x1eeed5b34dc64a19!2sHornos%20NACHiTOS!5e0!3m2!1ses!2sus!4v1747607075034!5m2!1ses!2sus" 
          width="220"
          height="120"
          style="border:0; border-radius: 8px; margin-top: 5px;"
          allowfullscreen=""
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade">
        </iframe>
      </div>
      <form style="display: flex; gap: 5px;">
        <input type="email" placeholder="Tu correo" required style="padding: 5px; border-radius: 4px; border: 1px solid #ccc;">
        <button type="submit" style="padding: 5px 10px; border-radius: 4px; background: #f86e40; color: white; border: none;">Suscribirse</button>
      </form>
    </div>
  </nav>
</footer>

<footer class="footerInferior">
  <nav class="footernav2">
    <div class="footer-container2">
      <p class="letrasFooter">&copy; 2025 Nachitos - Todos los derechos reservados</p>
    </div>
  </nav>
</footer>

</body>
</html>