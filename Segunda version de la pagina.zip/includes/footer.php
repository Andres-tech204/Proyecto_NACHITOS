<footer class="footerSuperior">
  <nav class="footernav1">
    <div class="footer-container1">
      <p class="letrasFooter">&copy; 2025 Nachitos - Todos los derechos reservados</p>
    </div>
  </nav>
</footer>

<footer class="footerInferior">
  <nav class="footernav2">
    <div class="footer-container2">
      <p class="letrasFooter">&copy; 2025 Nachitos - Todos los derechos reservados</p>
    </div>
  </nav>
</footer>

</body>
</html>
