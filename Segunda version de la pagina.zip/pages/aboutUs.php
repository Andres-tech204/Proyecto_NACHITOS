<?php
session_start();

include ('../includes/header.php');
include ('../includes/footer.php');

?>