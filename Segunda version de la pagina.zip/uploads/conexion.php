<?php
$host = "localhost";
$usuario = "root";
$contrasena = "";
$basededatos = "nachitos"; 


$conn = new mysqli($host, $usuario, $contrasena, $basededatos);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
} else {
    
}
?>
